package br.com.fiap.guinchoseguro.model;

public record Guincho (	
		Long idGuincho,
		String descricaoGuincho,
		int numeroDaPlaca
	) {}